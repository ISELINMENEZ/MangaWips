function sendToPhotoshop(text) {
  const font = document.getElementById('fontInput').value;
  const size = document.getElementById('sizeInput').value;
  const script = `
    var doc = app.activeDocument;
    var layer = doc.artLayers.add();
    layer.kind = LayerKind.TEXT;
    layer.textItem.contents = ${JSON.stringify(text)};
    layer.textItem.font = "${font}";
    layer.textItem.size = ${size};
    layer.textItem.position = [200, 200];
  `;
  new CSInterface().evalScript(script);
}

document.getElementById('fileInput').addEventListener('change', function(evt) {
  const file = evt.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function(e) {
    const lines = e.target.result.split('\\n');
    const list = document.getElementById('falaList');
    list.innerHTML = '';
    lines.forEach(function(line) {
      if (line.trim() === '') return;
      const div = document.createElement('div');
      div.className = 'line';
      div.textContent = line;
      div.addEventListener('click', function() {
        sendToPhotoshop(line);
      });
      list.appendChild(div);
    });
  };
  reader.readAsText(file);
});
